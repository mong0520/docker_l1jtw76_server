#!/bin/bash
#PATH=.:/usr/local/bin:/usr/bin:/bin
#export PATH

java -server -Xmx8m -Xms8m -jar l1jloader.jar